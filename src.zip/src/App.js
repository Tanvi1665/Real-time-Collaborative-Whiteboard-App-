import React from 'react';
import Whiteboard from './Whiteboard';

function App() {
  return (
    <div>
      <h1>Real-time Whiteboard</h1>
      <Whiteboard />
    </div>
  );
}

export default App;
