import React, { useRef, useEffect, useState } from "react";
import { io } from "socket.io-client";

const socket = io("http://localhost:5000");

export default function Whiteboard() {
  const canvasRef = useRef(null);
  const ctxRef = useRef(null);
  const [color, setColor] = useState("#000000");
  const [lineWidth, setLineWidth] = useState(5);
  const [tool, setTool] = useState("brush");
  const [drawing, setDrawing] = useState(false);
  const [lastPos, setLastPos] = useState({ x: 0, y: 0 });
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState("");

  useEffect(() => {
    const canvas = canvasRef.current;
    canvas.width = window.innerWidth * 0.7;
    canvas.height = window.innerHeight * 0.7;
    const ctx = canvas.getContext("2d");
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctxRef.current = ctx;
  }, []);

  useEffect(() => {
    socket.on("drawing", ({ x0, y0, x1, y1, color, lineWidth }) => {
      const ctx = ctxRef.current;
      ctx.strokeStyle = color;
      ctx.lineWidth = lineWidth;
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.lineTo(x1, y1);
      ctx.stroke();
      ctx.closePath();
    });

    socket.on("chatMessage", (msg) => {
      setChatMessages((prev) => [...prev, msg]);
    });

    socket.on("drawShape", (data) => {
      if (data.shape === "heart") drawHeart(data.x, data.y);
      else if (data.shape === "star") drawStar(data.x, data.y);
    });

    return () => {
      socket.off("drawing");
      socket.off("chatMessage");
      socket.off("drawShape");
    };
  }, []);

  const handleMouseDown = (e) => {
    const { offsetX, offsetY } = e.nativeEvent;
    setLastPos({ x: offsetX, y: offsetY });
    setDrawing(true);
  };

  const handleMouseMove = (e) => {
    if (!drawing) return;
    const { offsetX, offsetY } = e.nativeEvent;
    const x0 = lastPos.x;
    const y0 = lastPos.y;
    const x1 = offsetX;
    const y1 = offsetY;

    const ctx = ctxRef.current;
    ctx.strokeStyle = tool === "eraser" ? "#ffffff" : color;
    ctx.lineWidth = lineWidth;
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x1, y1);
    ctx.stroke();
    ctx.closePath();

    socket.emit("drawing", {
      x0,
      y0,
      x1,
      y1,
      color: ctx.strokeStyle,
      lineWidth: ctx.lineWidth,
    });

    setLastPos({ x: x1, y: y1 });
  };

  const handleMouseUp = () => {
    setDrawing(false);
  };

  const handleCommand = (input) => {
    const command = input.toLowerCase();

    if (command.includes("draw a heart")) {
      drawHeart(150, 150);
      socket.emit("drawShape", { shape: "heart", x: 150, y: 150 });
    } else if (command.includes("draw a star")) {
      drawStar(300, 150);
      socket.emit("drawShape", { shape: "star", x: 300, y: 150 });
    } else {
      socket.emit("chatMessage", input);
    }

    setChatInput("");
  };

  const handleChatSubmit = (e) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    handleCommand(chatInput);
  };

  const drawHeart = (x = 150, y = 150) => {
    const ctx = ctxRef.current;
    const size = 30;
    ctx.beginPath();
    ctx.fillStyle = "red";
    ctx.moveTo(x, y);
    ctx.bezierCurveTo(x, y - size, x - size, y - size, x - size, y);
    ctx.bezierCurveTo(x - size, y + size, x, y + size * 1.5, x, y + size * 2);
    ctx.bezierCurveTo(x, y + size * 1.5, x + size, y + size, x + size, y);
    ctx.bezierCurveTo(x + size, y - size, x, y - size, x, y);
    ctx.fill();
  };

  const drawStar = (cx = 300, cy = 150) => {
    const ctx = ctxRef.current;
    const spikes = 5,
      outerRadius = 30,
      innerRadius = 15;
    let rot = Math.PI / 2 * 3;
    let x = cx;
    let y = cy;
    const step = Math.PI / spikes;

    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x, y);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
    ctx.fillStyle = "gold";
    ctx.fill();
  };

  const handleMicClick = () => {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert("Speech Recognition not supported in this browser.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.start();

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setChatInput(transcript);
      setTimeout(() => {
        handleCommand(transcript);
      }, 300); // Let chatInput update
    };

    recognition.onerror = (event) => {
      console.error("Speech recognition error:", event.error);
    };
  };

  return (
    <div style={{ display: "flex" }}>
      <div>
        <canvas
          ref={canvasRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          style={{ border: "1px solid black" }}
        ></canvas>
        <div style={{ marginTop: 10 }}>
          <select value={tool} onChange={(e) => setTool(e.target.value)}>
            <option value="brush">Brush</option>
            <option value="eraser">Eraser</option>
          </select>
          {tool === "brush" && (
            <input
              type="color"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              style={{ marginLeft: 10 }}
            />
          )}
          <input
            type="range"
            min="1"
            max="50"
            value={lineWidth}
            onChange={(e) => setLineWidth(e.target.value)}
            style={{ marginLeft: 10 }}
          />
        </div>
      </div>
      <div style={{ marginLeft: 20 }}>
        <h3>Chat / Commands</h3>
        <div
          style={{
            border: "1px solid #ccc",
            height: 300,
            width: 300,
            overflowY: "auto",
            marginBottom: 10,
            padding: "5px",
          }}
        >
          {chatMessages.map((msg, idx) => (
            <div key={idx}>{msg}</div>
          ))}
        </div>
        <form onSubmit={handleChatSubmit} style={{ display: "flex", gap: 5 }}>
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder='Type or say "draw a heart"...'
            style={{ flex: 1 }}
          />
          <button type="button" onClick={handleMicClick}>
            🎤
          </button>
        </form>
      </div>
    </div>
  );
}
